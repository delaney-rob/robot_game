Robot Arm Game
**********************************

Author: Robert Delaney
Student No: C00161771
Date: 12/12/2014

**********************************


Instructions:

To run, double click executable.

Controls:

Left: moves robot left
Right: moves robot right
Up: moves whole arm up
Down: moves whole arm down
A: rotate upper arm negatively
D: rotate upper arm positively
W: open pincers
S: close pincers


